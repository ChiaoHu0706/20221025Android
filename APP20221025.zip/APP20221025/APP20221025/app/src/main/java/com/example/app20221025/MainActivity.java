package com.example.app20221025;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private Button sent;
    private Button clear;
    private EditText cs1;
    private EditText name;
    private EditText School;
    private EditText English;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sent=(Button)findViewById(R.id.button);
        clear=(Button)findViewById(R.id.button2);
        cs1=(EditText)findViewById(R.id.editText1) ;
        name=(EditText)findViewById(R.id.editText2) ;
        School=(EditText)findViewById(R.id.editText3) ;
        English=(EditText)findViewById(R.id.editText4) ;
        sent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it =new Intent(MainActivity.this,MainActivity2.class);
                String x=String.valueOf(English.getText());
                int a=Integer.valueOf(x);
                it.putExtra("班級",String.valueOf(cs1.getText()));
                it.putExtra("姓名",String.valueOf(name.getText()));
                it.putExtra("學號",String.valueOf(School.getText()));
                it.putExtra("英檢成績",a);

                startActivity(it);
            }
        });

        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cs1.setText("");
                name.setText("");
                School.setText("");
                English.setText("");
            }
        });

    }


}