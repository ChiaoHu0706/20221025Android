package com.example.app20221025;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {

    private TextView cs1;
    private TextView name;
    private TextView schoolNum;
    private TextView English;
    private TextView pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        cs1=(TextView) findViewById(R.id.tV1);
        name=(TextView) findViewById(R.id.tV2);
        schoolNum=(TextView) findViewById(R.id.tV3);
        English=(TextView) findViewById(R.id.tV4);
        pass=(TextView) findViewById(R.id.tV5);
        Intent it= getIntent();
        String cla=it.getStringExtra("班級");
        String nam=it.getStringExtra("姓名");
        String Num=it.getStringExtra("學號");
        int Eng=it.getIntExtra("英檢成績",0);
        cs1.setText("您的班級："+cla);
        name.setText("姓名："+nam);
        schoolNum.setText("學號："+Num);
        English.setText("英檢分數："+String.valueOf(Eng));

        if(Eng<225){
            pass.setText("請再考一次!!!"+String.valueOf(Eng)+"否則無法畢業");

        }
        else{
            pass.setText("您可以畢業!!!"+String.valueOf(Eng));
        }

    }
}